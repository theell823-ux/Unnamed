const steamHandlers = new Map();
const activeSteamBuilds = new Seq();

function registerSteamType(type, ratio, requireShoot){
    steamHandlers.put(type, {ratio: ratio, shoot: requireShoot});
}

registerSteamType(SItemTurret, 1/4, true);
registerSteamType(RSItemTurret, 1/20, true);
registerSteamType(MSItemTurret, 1/1, true);
registerSteamType(SDrill, 1/10, false);
registerSteamType(SGenerator, 1/5, false);
registerSteamType(SFactory, 1/10, false);
registerSteamType(SUnitFactory, 1/5, false);

Events.on(EventType.BlockBuildEndEvent, e => {
    let b = e.tile.build;
    if(b == null) return;
    if(steamHandlers.containsKey(b.block.constructor)){
        activeSteamBuilds.add(b);
    }
});

Events.on(EventType.BlockDestroyEvent, e => {
    activeSteamBuilds.remove(e.tile.build);
});

Events.run(EventType.Trigger.update, () => {

    for(let i = 0; i < activeSteamBuilds.size; i++){

        let b = activeSteamBuilds.get(i);
        if(b == null || !b.isValid() || b.dead) continue;

        let data = steamHandlers.get(b.block.constructor);
        if(data == null) continue;

        if(data.shoot && !b.isShooting()) continue;
        if(b.efficiency <= 0) continue;

        let cons = b.block.consumes.get(ConsumeType.liquid);
        if(cons == null || cons.liquid != Liquids.water) continue;

        let waterPerTick = cons.amount * b.efficiency * Time.delta;
        let steamAmount = waterPerTick * data.ratio;

        if(b.liquids.get(steam) < b.block.liquidCapacity){
            b.liquids.add(steam, steamAmount);
        }

    }

});

BlastLauncher.buildType = () => extend(StackConveyor.StackConveyorBuild, {

    _delay: 0,

    acceptItem(source, item){
        if(source == null) return false;
        if(this.relativeTo(source.tile) != (this.rotation + 2) % 4) return false;
        const t = source.block;
        if(t === BlastLauncher || t === BlastReceiver) return false;
        return this.items.total() < this.block.itemCapacity;
    },

    updateTile(){
        this.super$updateTile();

        if(this.items.total() >= this.block.itemCapacity){

            this._delay += Time.delta;

            if(this._delay >= 90){

                this._delay = 0;

                this.damage(this.maxHealth * 0.05);

                const item = this.items.first();
                if(item == null) return;

                for(let i = 0; i < 4; i++){
                    const other = this.nearby(i);
                    if(other == null) continue;
                    if(other.block === BlastReceiver){
                        if(other.acceptItem(this, item)){
                            this.items.remove(item, 1);
                            other.handleItem(this, item);
                            break;
                        }
                    }
                }
            }

        }else{
            this._delay = 0;
        }
    },

    write(write){
        this.super$write(write);
        write.f(this._delay);
    },

    read(read, revision){
        this.super$read(read, revision);
        this._delay = read.f();
    }

});

BlastReceiver.buildType = () => extend(StackConveyor.StackConveyorBuild, {

    acceptItem(source, item){
        if(source == null) return false;
        const t = source.block;
        if(t === BlastLauncher || t === BlastReceiver){
            return this.items.total() < this.block.itemCapacity;
        }
        return false;
    },

    handleItem(source, item){
        if(this.items.total() < this.block.itemCapacity){
            this.items.add(item, 1);
        }
    },

    updateTile(){
        this.super$updateTile();

        if(this.items.total() <= 0) return;

        const item = this.items.first();
        if(item == null) return;

        for(let i = 0; i < 4; i++){

            const other = this.nearby(i);
            if(other == null) continue;

            const b = other.block;

            if(
                b === BlastReceiver ||
                b instanceof CoreBlock ||
                b instanceof StorageBlock
            ){
                if(other.acceptItem(this, item)){
                    this.items.remove(item, 1);
                    other.handleItem(this, item);
                    break;
                }
            }
        }
    }

});