global.aether = global.aether || {};
global.aether.types = global.aether.types || {};

const SItemTurret = extend(ItemTurret, {

    setBars(){
        this.super$setBars();
        this.removeBar("liquid");

        this.addBar("water", e =>
            new Bar(
                "Water",
                Color.valueOf("4da6ff"),
                () => e.liquids.get(Liquids.water) / this.liquidCapacity
            )
        );

        this.addBar("steam", e =>
            new Bar(
                "Steam",
                Color.valueOf("d9d9d9"),
                () => e.liquids.get(global.aether.steam) / this.liquidCapacity
            )
        );
    }

});

global.aether.types.SItemTurret = SItemTurret;

const RSItemTurret = extend(ItemTurret, {

    setBars(){
        this.super$setBars();
        this.removeBar("liquid");

        this.addBar("water", e =>
            new Bar(
                "Water",
                Color.valueOf("4da6ff"),
                () => e.liquids.get(Liquids.water) / this.liquidCapacity
            )
        );

        this.addBar("steam", e =>
            new Bar(
                "Steam",
                Color.valueOf("d9d9d9"),
                () => e.liquids.get(steam) / this.liquidCapacity
            )
        );
    }

});

global.RSItemTurret = RSItemTurret;

const MSItemTurret = extend(ItemTurret, {

    setBars(){
        this.super$setBars();
        this.removeBar("liquid");

        this.addBar("water", e =>
            new Bar(
                "Water",
                Color.valueOf("4da6ff"),
                () => e.liquids.get(Liquids.water) / this.liquidCapacity
            )
        );

        this.addBar("steam", e =>
            new Bar(
                "Steam",
                Color.valueOf("d9d9d9"),
                () => e.liquids.get(steam) / this.liquidCapacity
            )
        );
    }

});

global.MSItemTurret = MSItemTurret;

const SDrill = extend(Drill, {

    setBars(){
        this.super$setBars();
        this.removeBar("liquid");

        this.addBar("water", e =>
            new Bar(
                "Water",
                Color.valueOf("4da6ff"),
                () => e.liquids.get(Liquids.water) / this.liquidCapacity
            )
        );

        this.addBar("steam", e =>
            new Bar(
                "Steam",
                Color.valueOf("d9d9d9"),
                () => e.liquids.get(steam) / this.liquidCapacity
            )
        );
    }

});

global.SDrill = SDrill;

const SGenerator = extend(PowerGenerator, {

    setBars(){
        this.super$setBars();
        this.removeBar("liquid");

        this.addBar("water", e =>
            new Bar(
                "Water",
                Color.valueOf("4da6ff"),
                () => e.liquids.get(Liquids.water) / this.liquidCapacity
            )
        );

        this.addBar("steam", e =>
            new Bar(
                "Steam",
                Color.valueOf("d9d9d9"),
                () => e.liquids.get(steam) / this.liquidCapacity
            )
        );
    }

});

global.SGenerator = SGenerator;

const SFactory = extend(GenericCrafter, {

    setBars(){
        this.super$setBars();
        this.removeBar("liquid");

        this.addBar("water", e =>
            new Bar(
                "Water",
                Color.valueOf("4da6ff"),
                () => e.liquids.get(Liquids.water) / this.liquidCapacity
            )
        );

        this.addBar("steam", e =>
            new Bar(
                "Steam",
                Color.valueOf("d9d9d9"),
                () => e.liquids.get(steam) / this.liquidCapacity
            )
        );
    }

});

global.SFactory = SFactory;

const SUnitFactory = extend(UnitFactory, {

    setBars(){
        this.super$setBars();
        this.removeBar("liquid");

        this.addBar("water", e =>
            new Bar(
                "Water",
                Color.valueOf("4da6ff"),
                () => e.liquids.get(Liquids.water) / this.liquidCapacity
            )
        );

        this.addBar("steam", e =>
            new Bar(
                "Steam",
                Color.valueOf("d9d9d9"),
                () => e.liquids.get(steam) / this.liquidCapacity
            )
        );
    }

});

global.SUnitFactory = SUnitFactory;

const BlastLauncher = extend(StackConveyor, "BlastLauncher", {

    itemCapacity: 50,
    hasLiquids: false,
    hasItems: true,
    rotate: true,
    update: true

});

const BlastReceiver = extend(StackConveyor, "BlastReceiver", {

    itemCapacity: 50,
    hasLiquids: false,
    hasItems: true,
    rotate: true,
    update: true

});