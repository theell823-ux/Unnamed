const steam = extend(Liquid, "steam", {
    gas: true,
    temperature: 1.1,
    viscosity: 0.05,
    heatCapacity: 0.4,
    explosiveness: 0
});

steam.color = Color.valueOf("d9d9d9");
steam.lightColor = Color.valueOf("ffffff");
steam.coolant = false;
steam.flammability = 0;
steam.barColor = Color.valueOf("d9d9d9");

global.steam = steam;